<?php get_header(); ?>
<div class="post">
<h1>Fehler!</h1>
Die gewünschte Seite ist nicht verfügbar.<br />
<?php include (TEMPLATEPATH . '/searchform.php'); ?>
</div>
<div id="sitemap">
<?php get_sidebar(); ?>
<?php get_footer(); ?>

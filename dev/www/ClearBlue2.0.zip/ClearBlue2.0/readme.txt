Wordpress Theme ClearBlue2.0

Für die Version 2.x

Hinweis: Dieses theme ist auch in Pink verfügbar: http://www.3fact.com/41-0-free-stuff.html

Tip für eine Logoeinbindung:

Ein Logo macht sich in diesem Theme besonders gut, wenn es mit 45% Deckkraft und einem Schlagschatten konzipiert ist. 
Wichtig ist die Transparenz, also das PNG-format benutzen.

Der IE bis 6.0 kann keine transparenten Images darstellen. daher bietet sich ein Hack an: 

.img {
filter:progid:DXImageTransform.
Microsoft.AlphaImageLoader (src='logo.png'), sizingMethod='scale');
}


Wer PSD-Dateien der einzelnen Grafiken benötigt kann mich gerne kontaktieren unter guetzlaff@3fact.com.

Viel Spass mit dem Theme.

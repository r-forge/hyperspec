<form method="get" action="<?php echo $_SERVER['PHP_SELF']; ?>">
<p>
<input value="" name="s" id="s" type="text" />
<input id="search" value="" type="submit" />
</p>
</form>
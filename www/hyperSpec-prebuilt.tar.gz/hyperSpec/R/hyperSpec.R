## wish list: slice_map
## wish list: parse arg of form x..y = z => x = list (y = z)
# TODO: write tests
# TODO: check docs

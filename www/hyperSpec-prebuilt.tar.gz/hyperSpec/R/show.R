###-----------------------------------------------------------------------------
###
###  show
###

setMethod ("show", "hyperSpec", function (object){
  print (object)
  invisible (NULL)
})

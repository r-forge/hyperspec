###-----------------------------------------------------------------------------
###
###  summary
###

setMethod ("summary", "hyperSpec", function (object, log = TRUE, ...){
  print (object, log = log, ...)
})

setMethod("colMeans", character(0),
NULL
)

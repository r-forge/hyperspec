###-----------------------------------------------------------------------------
###
###  stacked.offsets
###

stacked.offsets <- function (x, stacked = TRUE,
                             min.zero = FALSE, add.factor = 0.05, add.sum = 0,
                             #tight = FALSE, TODO
                             .spc = NULL){
  lvl <- NULL

  if (is.character (stacked))
    stacked <- unlist (x [[, stacked]])
  else if (isTRUE (stacked))
    stacked <- row.seq (x)

  if (is.factor (stacked)) {
    lvl <- levels (stacked)
    stacked <- as.numeric (stacked)
  } else if (!is.numeric (stacked))
    stop ("stacked must be either TRUE, the name of the extra data column to use for grouping, a factor or a numeric.")

  if (is.null (.spc))
    .spc <- x@data$spc

  ## using ave would be easier, but it splits the data possibly leading to huge lists.
  groups <- unique (as.numeric (stacked))
  offset <- matrix (nrow = 2, ncol = length (groups))
  
  for (i in seq_along (groups))
    offset[, i] <- range (.spc [stacked == groups [i], ], na.rm = TRUE)

  ## should the minimum be at zero (or less)?
  if (min.zero)
    offset [1, ] <- sapply (offset [1, ], min, 0, na.rm = TRUE)

  offset [2,] <- offset[2,] - offset [1,]

  ## add some extra space
  offset [2,] <- offset [2, ] *  (1 + add.factor) + add.sum
  
  offset <- c(-offset[1,], 0) + c (0, cumsum (offset[2,]))
  
  list (offsets = offset [seq_along (groups)],
        groups = stacked,
        levels = if (is.null (lvl)) stacked else lvl
        )
}

f <- function (x) c (x, x^2)

result <- c(2, 4) #  f (2)
###################################################
### chunk number 1: startup
###################################################
options(SweaveHooks=list(fig=function() par(mar = c (4.1, 4.1, 1, .6))))
options ("width" = 100)
library (hyperSpec)

# redefine lattice functions so that the result is pronted without external print command
plotmap <- function (...) print (hyperSpec:::plotmap (...))

setMethod ("levelplot", signature (x = "hyperSpec", data = "missing"),
   function (x, data, ...) {
	   l <- hyperSpec:::.levelplot (x = formula (spc ~ x * y), data = x, ...)
		print (l)
	}
)

setMethod ("levelplot", signature (x = "formula", data = "hyperSpec"), 
   function (x, data, ...) print (hyperSpec:::.levelplot (x, data, ...))
)

plotc <- function (...){
   call <- match.call () 
   call [[1]] <- hyperSpec:::plotc 
   print (eval (call))
}

plotvoronoi <- function (...) print (hyperSpec:::plotvoronoi (...))

# set standardized color palettes 
seq.palette <- colorRampPalette (c ("white", "gold", "dark green"), space = "Lab")

seq.palette   <- colorRampPalette (brewer.pal (9, "Greens"), space = "Lab")

seqsq.palette <- function (n) rgb (colorRamp (brewer.pal (9, "Greens"), space = "Lab") 
                                   (seq (1/3, 1, length.out = n)^2), maxColorValue = 255)

YG.palette <- function (n) rgb (colorRamp (brewer.pal (9, "Greens"), space = "Lab") 
                                (seq (1/3, 1, length.out = n)^2), maxColorValue = 255)

										  
div.palette <- colorRampPalette (c("#00008B", "#351C96", "#5235A2", "#6A4CAE", "#8164BA", "#967CC5", 
                                   "#AC95D1", "#C1AFDC", "#D5C9E8", "#E0E3E3", "#F8F8B0", "#F7E6C2", 
											  "#EFCFC6", "#E6B7AB", "#DCA091", "#D08977", "#C4725E", "#B75B46",
											  "#A9432F", "#9A2919", "#8B0000"), space = "Lab")



###################################################
### chunk number 2: init
###################################################
	library (hyperSpec)
	library (colorspace)


###################################################
### chunk number 3: classical-bl
###################################################
bl <- spc.fit.poly (chondro [c (1,3),, c(630, 1750)], chondro [c (1,3)])
plot (chondro [c (1,3)], plot.args = list (ylim = c(200, 600)), col = 1 : 2)
plot (chondro [c (1,3),, c(630, 1750)], add = TRUE, lines.args = list (type = "p", pch = 20), col = 1:2)
plot (bl, add = TRUE, col = 1 : 2)


###################################################
### chunk number 4: trace
###################################################
trace (spc.fit.poly.below, quote ({
  plot (fit.to[,, use.old], col = cl, add = TRUE, lines.args = list (pch = 20, type = "p"));
  lines (fit.to@wavelength, bl, col = cl);
}), at = 12, print = FALSE)


###################################################
### chunk number 5: fig1
###################################################
cols <- as (HSV(seq (240, 0, length.out = 9), 1, 1), "RGB")
cols@coords [,2] <- cols@coords[,2] / 2
cols <- hex (cols)

bl <- chondro [1] + 1
plot (chondro [1])
npts <- numeric (length (cols))
for (iter in seq_along (cols)){
	npts [iter] <- sum (chondro [[1]] < bl [[]])
	cl <- cols [iter]
	text (750, max (chondro [1]), paste ("Iter. ", iter, ": ", npts [iter], " support pts.", sep = ""),
			 pos = 1, col = cols [iter], offset = iter - 1)
	bl <- spc.fit.poly.below (chondro [1], poly.order = 1, npts.min = npts[iter]  - 1)
}
plot (chondro [1], add = TRUE)


###################################################
### chunk number 6: fig2
###################################################
bl <- chondro [1] + 1
plot (chondro [1], plot.args = list (ylim = range (chondro [1,, c(600 ~ 650, 1730 ~ 1800)])))
for (iter in seq_along (cols)){
	npts <- sum (chondro [[1]] < bl [[]])
	cl <- cols [iter]
	#cat ("Iteration", iter, ":", npts, "supporting points\n")
	bl <- spc.fit.poly.below (chondro [1], poly.order = 1, npts.min = npts - 1)
}
plot (chondro [1], add = TRUE)


###################################################
### chunk number 7: trace
###################################################
	trace (spc.fit.poly.below, quote ({ls ();
	plot (fit.to[,, use.old], col = cl, add = TRUE, lines.args = list (pch = pch, type = "p"),zeroline
= NULL);
	}), at = 12, print = FALSE)


###################################################
### chunk number 8: figspcrange
###################################################
plot (chondro [3,,1700 ~ 1750], plot.args = list (ylim = range (chondro [3,,1700 ~ 1750]) + c(-50, 0)))
cl <- "black"
pch = 1
bl <- spc.fit.poly.below (chondro [3,,1700 ~ 1750], NULL, poly.order = 1)
pch = 20
plot (chondro [3,,1720 ~ 1750], col = "blue", add = TRUE, lines.args = list (lwd = 2))
abline (bl[[]], col = "black")
cl <- "blue"
bl <- spc.fit.poly.below (chondro [3,,1720 ~ 1750], NULL, poly.order = 1)
abline (bl[[]], col = "blue")


###################################################
### chunk number 9: trace2
###################################################
	trace (spc.fit.poly.below, quote ({ls ();
	plot (fit.to[,, use.old], col = cl, add = TRUE, lines.args = list (pch = pch, type = "p"), zeroline = NULL);
	lines (fit.to@wavelength, bl, col = cl);
	}), at = 12, print = FALSE)


###################################################
### chunk number 10: fit-apply
###################################################
system.time (spc.fit.poly.below (chondro[], NULL, npts.min = 20))
system.time (spc.fit.poly.below (chondro [,, c (min ~ 700, 1700 ~ max)], NULL, npts.min = 20))


###################################################
### chunk number 11: figorder
###################################################
plot (chondro [1], lines.args = list (type = "n"))
cols <- c ("black", "blue", "#008000", "red")
for (o in 0 : 3){
		cl <- cols [o + 1]
		bl <- spc.fit.poly.below (chondro [1], poly.order = o)
	}
	plot (chondro [1], add = TRUE)


###################################################
### chunk number 12: fig3
###################################################

spc <- new ("hyperSpec", spc = matrix (rnorm (30, mean = 100, sd = 2), ncol = 30))
noise <- 10
plot (spc)
trace (spc.fit.poly.below, quote ({
					plot (fit.to[,, use.old], col = cl, add = TRUE, lines.args = list (pch = 20, type = "p"), zeroline = NULL);
					lines (fit.to@wavelength, bl, col = cl);
					lines (fit.to@wavelength, bl + noise, col = cl, lty = 2)
				}), at = 12, print = FALSE)

cols <- as (HSV(seq (240, 0, length.out = 2), 1, 1), "RGB")
cols@coords [,2] <- cols@coords[,2] / 2
cols <- hex (cols)

bl <- spc + 15
for (iter in seq_along (cols)){
	npts <- sum (spc [[]] < (bl [[]] + noise))
	cl <- cols [iter]
	bl <- spc.fit.poly.below (spc, poly.order = 0, npts.min = npts, noise = noise)
	text (5, max (spc[]), paste ("Iter. ", iter, ": ", npts, " support pts.", sep = ""),
			pos = 1, col = cols [iter], offset = iter - 1)
}
cl <- "black"
trace (spc.fit.poly.below, quote ({
					plot (fit.to[,, use.old], col = cl, add = TRUE, lines.args = list (type = "p"), zeroline = NULL);
					lines (fit.to@wavelength, bl, col = cl);
				}), at = 12, print = FALSE)
bl <- spc.fit.poly.below (spc, poly.order = 0)


###################################################
### chunk number 13: fig4
###################################################
trace (spc.fit.poly.below, quote ({
					plot (fit.to[,, use.old], col = cl, add = TRUE, lines.args = list (pch = 20, type = "p"), zeroline = NULL);
					lines (fit.to@wavelength, bl, col = cl);
					lines (fit.to@wavelength, bl + noise, col = cl, lty = 2)
				}), at = 12, print = FALSE)
cols <- as (HSV(seq (240, 0, length.out = 10), 1, 1), "RGB")
cols@coords [,2] <- cols@coords[,2] / 2
cols <- hex (cols)
bl <- chondro [1] + 15
plot (chondro [1])
for (iter in seq_along (cols)){
	npts <- sum (chondro [[1]] < bl [[]] + noise)
	cl <- cols [iter]
	text (750, max (chondro [1]), paste ("Iter. ", iter, ": ", npts, " support pts.", sep = ""),
			pos = 1, offset = iter-1, col = cols [iter])
	bl <- spc.fit.poly.below (chondro [1], poly.order = 1, npts.min = npts - 1, noise = noise)
}
plot (chondro [1], add = TRUE)


###################################################
### chunk number 14: fig5
###################################################
trace (spc.fit.poly.below, quote ({
					plot (fit.to[,, use.old], col = cl, add = TRUE, lines.args = list (pch = 20, type = "p"));
					lines (fit.to@wavelength, bl, col = cl);
					lines (fit.to@wavelength, bl + noise, col = cl, lty = 2)
				}), at = 12, print = FALSE)
cols <- as (HSV(seq (240, 0, length.out = 10), 1, 1), "RGB")
cols@coords [,2] <- cols@coords[,2] / 2
cols <- hex (cols)
bl <- chondro [1] + 15
plot (chondro [1], plot.args = list (ylim = range (chondro [1,, c(600 ~ 650, 1730 ~ 1800)])))
for (iter in seq_along (cols)){
	npts <- sum (chondro [[1]] < bl [[]] + noise)
	cl <- cols [iter]
	cat ("Iteration", iter, ":", npts, "supporting points\n")
	bl <- spc.fit.poly.below (chondro [1], poly.order = 1, npts.min = npts - 1, noise = noise)
}
plot (chondro [1], add = TRUE)
untrace (spc.fit.poly.below)


###################################################
### chunk number 15: cleanup
###################################################
rm (list = ls () ) 



###################################################
### chunk number 1: startup
###################################################
options(SweaveHooks=list(fig=function() par(mar = c (4.1, 4.1, 1, .6))))
options ("width" = 100)
library (hyperSpec)

# redefine lattice functions so that the result is pronted without external print command
plotmap <- function (...) print (hyperSpec:::plotmap (...))

setMethod ("levelplot", signature (x = "hyperSpec", data = "missing"),
   function (x, data, ...) {
	   l <- hyperSpec:::.levelplot (x = formula (spc ~ x * y), data = x, ...)
		print (l)
	}
)

setMethod ("levelplot", signature (x = "formula", data = "hyperSpec"), 
   function (x, data, ...) print (hyperSpec:::.levelplot (x, data, ...))
)

plotc <- function (...){
   call <- match.call () 
   call [[1]] <- hyperSpec:::plotc 
   print (eval (call))
}

plotvoronoi <- function (...) print (hyperSpec:::plotvoronoi (...))

# set standardized color palettes 
seq.palette <- colorRampPalette (c ("white", "gold", "dark green"), space = "Lab")

seq.palette   <- colorRampPalette (brewer.pal (9, "Greens"), space = "Lab")

seqsq.palette <- function (n) rgb (colorRamp (brewer.pal (9, "Greens"), space = "Lab") 
                                   (seq (1/3, 1, length.out = n)^2), maxColorValue = 255)

YG.palette <- function (n) rgb (colorRamp (brewer.pal (9, "Greens"), space = "Lab") 
                                (seq (1/3, 1, length.out = n)^2), maxColorValue = 255)

										  
div.palette <- colorRampPalette (c("#00008B", "#351C96", "#5235A2", "#6A4CAE", "#8164BA", "#967CC5", 
                                   "#AC95D1", "#C1AFDC", "#D5C9E8", "#E0E3E3", "#F8F8B0", "#F7E6C2", 
											  "#EFCFC6", "#E6B7AB", "#DCA091", "#D08977", "#C4725E", "#B75B46",
											  "#A9432F", "#9A2919", "#8B0000"), space = "Lab")



###################################################
### chunk number 2: importfun
###################################################
read.PE <- function (files = "*.txt", skip = 54) {
	files <- Sys.glob (files)

	buffer <- matrix (scan (files [1], skip = skip), ncol = 2, byrow = TRUE)

	wavelength <- buffer [, 1]
	spc <- matrix (ncol = nrow (buffer), nrow = length (files))

	spc [1, ] <-  buffer [, 2]

	for (f in seq (along = files)[-1]) {

		buffer <- matrix (scan (files [f], skip = skip), ncol = 2, byrow = TRUE)

		if (! all.equal (buffer [, 1], wavelength))
			stop (paste(files [f], "has different wavelength axis."))

		spc [f, ] <- buffer[, 2]
	}

	new ("hyperSpec", wavelength = wavelength, spc = spc,
			label = list (.wavelength = expression (lambda[fl] / nm),
					spc = "I / a.u."))
}


###################################################
### chunk number 3: import
###################################################
flu <- read.PE ("rawdata/flu?.txt")


###################################################
### chunk number 4: rawspc
###################################################
flu


###################################################
### chunk number 5: rawfig
###################################################
plot (flu)


###################################################
### chunk number 6: newdata
###################################################
flu$c <- seq (from = 0.05, to = 0.30, by = 0.05)
labels (flu, "c") <- "c / (mg / l)"
flu


###################################################
### chunk number 7: newc
###################################################
flu$c


###################################################
### chunk number 8: calplot1
###################################################
plotc (flu[,,450])


###################################################
### chunk number 9: cutspc
###################################################
flu <- flu [,,450]
labels (flu, "spc") <- expression (I ["450 nm"] / a.u.)


###################################################
### chunk number 10: calplot2
###################################################
plotc (flu, xlim = range (0, flu$c), ylim = range (0, flu$spc))


###################################################
### chunk number 11: abbrev
###################################################
flu[[]]
flu$.
flu$..


###################################################
### chunk number 12: cal
###################################################
calibration <- lm (c ~ spc, data = flu$.)


###################################################
### chunk number 13: summarymodel
###################################################
summary (calibration)


###################################################
### chunk number 14: pred
###################################################
I <- c (125, 400)
conc <- predict (calibration, newdata = list (spc = as.matrix(I)), interval = "prediction", 
                 level = .99)
conc


###################################################
### chunk number 15: calplot3
###################################################

int <- list (spc = as.matrix(seq (min (flu), max(flu), length.out = 25)))
ci <- predict (calibration, newdata = int, interval = "confidence", level = 0.99)

panel.ci <-  function (x, y, ...,
                       intensity, ci.lwr, ci.upr, ci.col = "#606060") {
   panel.xyplot (x, y, ...)
   panel.lmline (x, y,...)
   panel.lines (ci.lwr, intensity, col = ci.col)
   panel.lines (ci.upr, intensity, col = ci.col)
}

plotc (flu, panel = panel.ci,
       intensity = int$spc, ci.lwr = ci [, 2], ci.upr = ci [, 3])
## # extrapolate to lower intensities
## int <- list (spc = as.matrix(0 : min (flu)))
## ci <- predict (calibration, newdata = int, interval = "confidence", level = 0.99)
## matlines (ci, int$spc, col = c ("red","#606060","#606060"), lty = 3)

# our example
#lines (conc[-1], rep(I, 2), col = "blue")
#points (conc[1], I, col = "blue", pch = 4, cex = 0.5)


###################################################
### chunk number 16: calplot4.1
###################################################
flu$type <- "data points"


###################################################
### chunk number 17: calplot4.2
###################################################
tmp <- new ("hyperSpec", spc = as.matrix(seq (min (flu), max(flu), length.out = 25)),
                         wavelength = 450)
ci <-  predict (calibration, newdata = tmp$., interval = "confidence", level = 0.99)
tmp <- tmp [rep (seq (tmp, index = TRUE), 3)]
tmp$c <- as.numeric (ci)
tmp$type <- rep (colnames (ci), each = 25)

flu <- rbind (flu, tmp)


###################################################
### chunk number 18: calplot4
###################################################
panel.predict <- function (x, y, ..., 
                 intensity, ci, pred.col = "red", pred.pch = 19, pred.cex = 1) {
   panel.xyplot (x, y, ...)
   mapply (function (i, lwr, upr, ...) {
                 panel.lines (c (lwr, upr), rep (i, 2), ...)
              }, 
           intensity, ci [, 2], ci [, 3], MoreArgs = list (col = pred.col))
   panel.xyplot (ci [, 1], intensity, col = pred.col, pch = pred.pch, cex = pred.cex, type = "p")
}


plotc (flu, groups = type, type = c("l", "p"),
       col = c ("black", "black", "#606060", "#606060"), 
       pch = c (19, NA, NA, NA), cex = 0.5, 
       lty = c (0, 1, 1, 1),
       panel = panel.predict,
       intensity = I,
       ci = conc,
       pred.cex = 0.5)


###################################################
### chunk number 19: cleanup
###################################################
rm (list = ls () ) 



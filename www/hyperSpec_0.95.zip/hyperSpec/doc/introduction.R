###################################################
### chunk number 1: startup
###################################################
options(SweaveHooks=list(fig=function() par(mar = c (4.1, 4.1, 1, .6), family="serif")))
options ("width" = 100)
library (hyperSpec)
plotmap <- function (...) print (hyperSpec:::plotmap (...))
setMethod ("levelplot", signature (x = "hyperSpec", data = "missing"),
           function (x, data, ...) {
			    l <- hyperSpec:::.levelplot (x = formula (spc ~ x * y), data = x, ...)
             print (l)
           })
setMethod ("levelplot", signature (x = "formula", data = "hyperSpec"), 
           function (x, data, ...) print (hyperSpec:::.levelplot (x, data, ...))
)

plotvoronoi <- function (...) print (hyperSpec:::plotvoronoi (...))

seq.palette <- colorRampPalette (c ("white", "gold", "dark green"), space = "Lab")

seq.palette   <- colorRampPalette (brewer.pal (9, "Greens"), space = "Lab")
seqsq.palette <- function (n) rgb (colorRamp (brewer.pal (9, "Greens"), space = "Lab") 
                                   (seq (1/3, 1, length.out = n)^2), maxColorValue = 255)
YG.palette <- function (n) rgb (colorRamp (brewer.pal (9, "Greens"), space = "Lab") 
                                   (seq (1/3, 1, length.out = n)^2), maxColorValue = 255)

div.palette <- colorRampPalette (c("#00008B", "#351C96", "#5235A2", "#6A4CAE", "#8164BA", "#967CC5", 
                                   "#AC95D1", "#C1AFDC", "#D5C9E8", "#E0E3E3", "#F8F8B0", "#F7E6C2", 
											  "#EFCFC6", "#E6B7AB", "#DCA091", "#D08977", "#C4725E", "#B75B46",
											  "#A9432F", "#9A2919", "#8B0000"), space = "Lab")


# c (#"#F8F8B0", 
# "#F7E6C2", 
# 											  "#EFCFC6", "#E6B7AB", "#DCA091", "#D08977", "#C4725E", "#B75B46",
# 											  "#A9432F", "#9A2919", "#8B0000"), space = "Lab")
# rev (c("#00008B", "#351C96", "#5235A2", "#6A4CAE", "#8164BA", "#967CC5", 
#                                         "#AC95D1", "#C1AFDC", "#D5C9E8", "#E0E3E3", "#F8F8B0")), space = "Lab")



###################################################
### chunk number 2:  eval=FALSE
###################################################
## .is.hy (object)
## validObject (object)


###################################################
### chunk number 3: init
###################################################
library (hyperSpec)


###################################################
### chunk number 4: help1 eval=FALSE
###################################################
## ? plotmath


###################################################
### chunk number 5: help2 eval=FALSE
###################################################
## demo (plotmath)


###################################################
### chunk number 6: print
###################################################
chondro
summary (chondro)


###################################################
### chunk number 7: nwl
###################################################
nrow (chondro)
nwl (chondro)
ncol (chondro)
dim (chondro)


###################################################
### chunk number 8: names
###################################################
colnames (chondro)


###################################################
### chunk number 9: scan.txt.Renishaw
###################################################
paracetamol <- scan.txt.Renishaw ("rawdata/paracetamol.txt", "spc")
paracetamol


###################################################
### chunk number 10:  eval=FALSE
###################################################
## header <- list (samples = 64 * no.images.in.row,
##                 lines = 64 * no.images.in.column,
##                 bands = no.data.points.per.spectrum,
##                 `data type` = 4,
##                 interleave = "bip")


###################################################
### chunk number 11: cbind
###################################################
cbind (chondro [, , 600 ~ 800], chondro [, , 1600 ~ 1800])
rbind (chondro [, , 600 ~ 800], chondro [, , 600 ~ 800])


###################################################
### chunk number 12: delspc
###################################################
flu [1 : 3]
flu [-3]
chondro  [chondro$y > 10]


###################################################
### chunk number 13: data
###################################################
colnames (chondro)
chondro [[1 : 3, 1]]
chondro [[1 : 3, -3]]
chondro [[1 : 3, "x"]]
chondro [[1 : 3, c (TRUE, FALSE, FALSE)]]


###################################################
### chunk number 14: data2
###################################################
flu$c


###################################################
### chunk number 15: data3
###################################################
flu$n <- list (1 : 6, label = "sample no.")


###################################################
### chunk number 16: wl2ivec
###################################################
wl2i (flu, 405 : 410)


###################################################
### chunk number 17: wl2ivec2
###################################################
wl2i (flu, 405 ~ 410)


###################################################
### chunk number 18: wl2ivec3
###################################################
wl2i (chondro, 1000 : 1010)


###################################################
### chunk number 19: wl2ivec4
###################################################
wl2i (chondro, 1000 ~ 1010)


###################################################
### chunk number 20: wl2i.minmax
###################################################
wl2i (flu, min ~ 410)


###################################################
### chunk number 21: wl2i.im
###################################################
wl2i (flu, 450 - 2i ~ 450 + 2i)
wl2i (flu, max - 2i ~ max)


###################################################
### chunk number 22: wl2i.list
###################################################
wl2i (flu, 450 - 2i ~ 450 + 2i)
wl2i (flu, c (min ~ 406.5, max - 2i ~ max))


###################################################
### chunk number 23: plotspc
###################################################
plotspc (flu)


###################################################
### chunk number 24: plotspcmeansd
###################################################
plot (chondro, "spcmeansd")


###################################################
### chunk number 25: plotc
###################################################
plotc (flu)


###################################################
### chunk number 26: plotmap
###################################################
YG <- colorRampPalette (c ("white", "gold", "dark green"), space = "Lab")
plotmap (chondro, col.regions = YG (20))


###################################################
### chunk number 27: ms
###################################################
fake.mass.spec <- new ("hyperSpec", spc = matrix (100*runif (25), nrow = 1),
   wavelength = 1 : 25 + 28,
   label = list (spc = expression (e^"-" / s), .wavelength = expression (m / z)))
plot (fake.mass.spec, lines.args = list (type = "h"))


###################################################
### chunk number 28: plotspcadd
###################################################
plot (paracetamol, wl.range = c (300 ~ 1800, 2800 ~ max), xoffset = 850, wl.reverse = TRUE, col = "blue")


###################################################
### chunk number 29: plotmat1
###################################################
levelplot (spc ~ .wavelength * t, laser, col.regions = YG (20))


###################################################
### chunk number 30: plotmat2
###################################################
print (plot (flu, "mat", contour = TRUE, labels = TRUE, col = "#00000080"))


###################################################
### chunk number 31: cut.wl
###################################################
flu [,, min ~ 408.5]
flu [[,, c (min ~ min + 2i, max - 2i ~ max)]]


###################################################
### chunk number 32: fig-loess
###################################################
plot (paracetamol, wl.range = c (300 ~ 1800, 2800 ~ max), xoffset = 850)
p <- spc.loess (paracetamol, c(seq (300, 1800, 2), seq (2850, 3150, 2)))
plot (p, wl.range = c (300 ~ 1800, 2800 ~ max), xoffset = 850, col = "red", add = TRUE)


###################################################
### chunk number 33: fig-loess-kl
###################################################
plot (paracetamol [, , 1600 ~ 1670])
plot (p [, , 1600 ~ 1670], col = "red", add = TRUE)


###################################################
### chunk number 34: ofs
###################################################
offsets <- apply (chondro, 1, min)
chondro.offset.corrected <- sweep (chondro, 1, offsets, "-")


###################################################
### chunk number 35: bl
###################################################
bl <- spc.fit.poly.below (chondro)
chondro <- chondro - bl


###################################################
### chunk number 36: norm
###################################################
factors <- 1 / apply (chondro, 1, mean)
chondro <- sweep (chondro, 1, factors, "*")


###################################################
### chunk number 37: centre-flu
###################################################
flu.centered <- sweep (flu, 2, apply (flu, 2, mean), "-")


###################################################
### chunk number 38: fig-centre-flu
###################################################
plot (flu.centered)


###################################################
### chunk number 39: perc
###################################################
chondro <- sweep (chondro, 2, apply (chondro, 2, quantile, 0.05), "-")


###################################################
### chunk number 40: fig-centre-ch
###################################################
plot (chondro, "spcprctl5")


###################################################
### chunk number 41: msc eval=FALSE
###################################################
## library (pls)
## chondro.msc <- chondro
## chondro.msc [[]] <- msc (chondro [[]])


###################################################
### chunk number 42: label eval=FALSE
###################################################
## labels (absorbance.spectra)$spc <- "A"


###################################################
### chunk number 43: pca
###################################################
pca <- prcomp (~ spc, data = chondro$., centre = FALSE)


###################################################
### chunk number 44: decomp
###################################################
scores <- decomposition (chondro, pca$x, label.wavelength = "PC", label.spc = "score / a.u.")
loadings <- decomposition (chondro, t(pca$rotation), scores = FALSE, label.spc = "loading I / a.u.")


###################################################
### chunk number 45: pca-load
###################################################
plot (loadings [1:3], stacked = TRUE)


###################################################
### chunk number 46: pca-score
###################################################
plotmap (scores [,,2], col.regions = div.palette (20))


###################################################
### chunk number 47: hca
###################################################
dist <- pearson.dist (chondro [[]])
dendrogram <- hclust (dist, method = "ward")


###################################################
### chunk number 48: dend
###################################################
plot (dendrogram)


###################################################
### chunk number 49: dendcut
###################################################
chondro$clusters <- as.factor (cutree (dendrogram, k = 3))


###################################################
### chunk number 50: clustname
###################################################
levels (chondro$clusters) <- c ("matrix", "lacuna", "cell")


###################################################
### chunk number 51: clustmap
###################################################
cluster.cols <- c ("dark blue", "orange", "#C02020")
plotmap (chondro, clusters ~ x * y, col.regions = cluster.cols)


###################################################
### chunk number 52: clustmean
###################################################
means <- aggregate (chondro, by = chondro$clusters, mean_pm_sd)
plot (means, col = cluster.cols, stacked = ".aggregate", fill = ".aggregate")


###################################################
### chunk number 53: split
###################################################
clusters <- split (chondro, chondro$clusters)
clusters


###################################################
### chunk number 54: cleanup
###################################################
rm (list = ls () )



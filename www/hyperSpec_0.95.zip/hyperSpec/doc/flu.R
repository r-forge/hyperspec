###################################################
### chunk number 1: startup
###################################################
options(SweaveHooks=list(fig=function() par(mar = c (4.1, 4.1, 1, .6), family="serif")))
options ("width" = 100)
library (hyperSpec)
plotmap <- function (...) print (hyperSpec:::plotmap (...))
setMethod ("levelplot", signature (x = "hyperSpec", data = "missing"),
           function (x, data, ...) {
			    l <- hyperSpec:::.levelplot (x = formula (spc ~ x * y), data = x, ...)
             print (l)
           })
setMethod ("levelplot", signature (x = "formula", data = "hyperSpec"), 
           function (x, data, ...) print (hyperSpec:::.levelplot (x, data, ...))
)

plotvoronoi <- function (...) print (hyperSpec:::plotvoronoi (...))

seq.palette <- colorRampPalette (c ("white", "gold", "dark green"), space = "Lab")

seq.palette   <- colorRampPalette (brewer.pal (9, "Greens"), space = "Lab")
seqsq.palette <- function (n) rgb (colorRamp (brewer.pal (9, "Greens"), space = "Lab") 
                                   (seq (1/3, 1, length.out = n)^2), maxColorValue = 255)
YG.palette <- function (n) rgb (colorRamp (brewer.pal (9, "Greens"), space = "Lab") 
                                   (seq (1/3, 1, length.out = n)^2), maxColorValue = 255)

div.palette <- colorRampPalette (c("#00008B", "#351C96", "#5235A2", "#6A4CAE", "#8164BA", "#967CC5", 
                                   "#AC95D1", "#C1AFDC", "#D5C9E8", "#E0E3E3", "#F8F8B0", "#F7E6C2", 
											  "#EFCFC6", "#E6B7AB", "#DCA091", "#D08977", "#C4725E", "#B75B46",
											  "#A9432F", "#9A2919", "#8B0000"), space = "Lab")


# c (#"#F8F8B0", 
# "#F7E6C2", 
# 											  "#EFCFC6", "#E6B7AB", "#DCA091", "#D08977", "#C4725E", "#B75B46",
# 											  "#A9432F", "#9A2919", "#8B0000"), space = "Lab")
# rev (c("#00008B", "#351C96", "#5235A2", "#6A4CAE", "#8164BA", "#967CC5", 
#                                         "#AC95D1", "#C1AFDC", "#D5C9E8", "#E0E3E3", "#F8F8B0")), space = "Lab")



###################################################
### chunk number 2: init
###################################################
library (graphics)
library (hyperSpec)


###################################################
### chunk number 3: importfun
###################################################
read.PE <- function (files = "*.txt", skip = 54) {
	files <- Sys.glob (files)

	buffer <- matrix (scan (files [1], skip = skip), ncol = 2, byrow = TRUE)

	wavelength <- buffer [, 1]
	spc <- matrix (ncol = nrow (buffer), nrow = length (files))

	spc [1, ] <-  buffer [, 2]

	for (f in seq (along = files)[-1]) {

		buffer <- matrix (scan (files [f], skip = skip), ncol = 2, byrow = TRUE)

		if (! all.equal (buffer [, 1], wavelength))
			stop (paste(files [f], "has different wavelength axis."))

		spc [f, ] <- buffer[, 2]
	}

	new ("hyperSpec", wavelength = wavelength, spc = spc,
			label = list (.wavelength = expression (lambda[fl] / nm),
					spc = "I / a.u."))
}


###################################################
### chunk number 4: import
###################################################
flu <- read.PE ("rawdata/flu?.txt")


###################################################
### chunk number 5: rawspc
###################################################
flu


###################################################
### chunk number 6: rawfig
###################################################
plot (flu)


###################################################
### chunk number 7: newdata
###################################################
flu$c <- seq (from = 0.05, to = 0.30, by = 0.05)
labels (flu, "c") <- "c / (mg / l)"
flu


###################################################
### chunk number 8: newc
###################################################
flu$c


###################################################
### chunk number 9: calplot1
###################################################
plotc (flu[,,445])


###################################################
### chunk number 10: cutspc
###################################################
flu <- flu [,,445]


###################################################
### chunk number 11: calplot2
###################################################
plotc (flu, zlab = expression (I ["450 nm"] / a.u.),
	   plot.args = list (xlim = range (0, flu$c), ylim = range (0, flu$spc)))


###################################################
### chunk number 12: abbrev
###################################################
flu[[]]
flu$.
flu$..


###################################################
### chunk number 13: cal
###################################################
calibration <- lm (c ~ spc, data = flu$.)


###################################################
### chunk number 14: summarymodel
###################################################
summary (calibration)


###################################################
### chunk number 15: pred
###################################################
I <- 125
conc <- predict (calibration, newdata = list (spc = as.matrix(I)), interval = "prediction", 
                 level = .99)
conc


###################################################
### chunk number 16: calplot3
###################################################
plotc (flu, zlab = expression (I ["450 nm"] / a.u.),
       plot.args = list (xlim = range (0, flu$c), ylim = range (0, flu$spc)))

int <- list (spc = as.matrix(min (flu) : max(flu)))
ci <- predict (calibration, newdata = int, interval = "confidence", level = 0.99)
matlines (ci, int$spc, col = c ("red","gray","gray"), lty = 1)

# extrapolate to lower intensities
int <- list (spc = as.matrix(0 : min (flu)))
ci <- predict (calibration, newdata = int, interval = "confidence", level = 0.99)
matlines (ci, int$spc, col = c ("red","#606060","#606060"), lty = 3)

# our example
lines (conc[-1], rep(I, 2), col = "blue")
points (conc[1], I, col = "blue", pch = 4, cex = 0.5)


###################################################
### chunk number 17: cleanup
###################################################
rm (list = ls () ) 



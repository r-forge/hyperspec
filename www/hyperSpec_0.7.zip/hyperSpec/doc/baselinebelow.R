###################################################
### chunk number 1: startup
###################################################
options(SweaveHooks=list(fig=function() par(mar = c (3.6, 3.6, .6, .6), family="serif")))
options ("width" = 90)


###################################################
### chunk number 2: init
###################################################
	library (hyperSpec)
	library (colorspace)


###################################################
### chunk number 3: trace
###################################################
	trace (spc.fit.poly.below, quote ({ls ();
	plot (fit.to[,, use.old], col = cl, add = TRUE, lines.args = list (pch = pch, type = "p"), zeroline = NULL);
	lines (fit.to@wavelength, bl, col = cl)
	}), at = 10, print = FALSE)


###################################################
### chunk number 4: figspcrange
###################################################
plot (chondro [1,,1700 ~ max], plot.args = list (ylim = range (chondro [1,,1700 ~ max] + c(-100, 0))))
cl <- "black"
pch = 1
bl <- spc.fit.poly.below (chondro [1,,1700 ~ max], poly.order = 1)
pch = 20
plot (chondro [1,,1715 ~ max], col = "blue", add = TRUE, lines.args = list (lwd = 2))
cl <- "blue"
bl <- spc.fit.poly.below (chondro [1,,1715 ~ max], poly.order = 1)


###################################################
### chunk number 5: fit-apply
###################################################
system.time (spc.fit.poly.below (chondro[], NULL, poly.order = 1, npts.min = 20,
            noise = 12))
system.time (spc.fit.poly.below (chondro [,, -wl2i (chondro, 700 ~ 1700), wl.index = TRUE],
				NULL, poly.order = 1, npts.min = 20, noise = 12))


###################################################
### chunk number 6: figorder
###################################################
plot (chondro [1], lines.args = list (type = "n"))
cols <- c ("black", "blue", "#008000", "red")
for (o in 0 : 3){
		cl <- cols [o + 1]
		bl <- spc.fit.poly.below (chondro [1], poly.order = o)
	}
	plot (chondro [1], add = TRUE)


###################################################
### chunk number 7: fig1
###################################################
cols <- as (HSV(seq (240, 0, length.out = 9), 1, 1), "RGB")
cols@coords [,2] <- cols@coords[,2] / 2
cols <- hex (cols)

bl <- chondro [1] + 1
plot (chondro [1])
npts <- numeric (length (cols))
for (iter in seq_along (cols)){
	npts [iter] <- sum (chondro [[1]] < bl [[]])
	cl <- cols [iter]
	text (600, 1000 - 50 * iter, paste ("Iter. ", iter, ": ", npts [iter], " support pts.", sep = ""),
			adj = c(0, 0), col = cols [iter])
	bl <- spc.fit.poly.below (chondro [1], poly.order = 1, npts.min = npts[iter]  - 1)
}
plot (chondro [1], add = TRUE)


###################################################
### chunk number 8: fig2
###################################################
bl <- chondro [1] + 1
plot (chondro [1], plot.args = list (ylim = range (chondro [1,, c(600 ~ 650, 1730 ~ 1800)])))
for (iter in seq_along (cols)){
	npts <- sum (chondro [[1]] < bl [[]])
	cl <- cols [iter]
	#cat ("Iteration", iter, ":", npts, "supporting points\n")
	bl <- spc.fit.poly.below (chondro [1], poly.order = 1, npts.min = npts - 1)
}
plot (chondro [1], add = TRUE)


###################################################
### chunk number 9: fig3
###################################################
noise <- 12
plot (chondro [1,,1730 ~ max], plot.args = list(ylim = range (chondro [1,, 1730 ~ max])))
trace (spc.fit.poly.below, quote ({
					plot (fit.to[,, use.old], col = cl, add = TRUE, lines.args = list (pch = 20, type = "p"), zeroline = NULL);
					lines (fit.to@wavelength, bl, col = cl);
					lines (fit.to@wavelength, bl + noise, col = cl, lty = 2)
				}), at = 10, print = FALSE)

cols <- as (HSV(seq (240, 0, length.out = 2), 1, 1), "RGB")
cols@coords [,2] <- cols@coords[,2] / 2
cols <- hex (cols)

bl <- chondro [1,,1730 ~ max] + 15
for (iter in seq_along (cols)){
	npts <- sum (chondro [[1,,1730 ~ max]] < (bl [[]] + noise))
	cl <- cols [iter]
	bl <- spc.fit.poly.below (chondro [1,,1730 ~ max], poly.order = 1, npts.min = npts, noise = noise)
	text (1800, 20 - 3 * iter, paste ("Iter. ", iter, ": ", npts, " support pts.", sep = ""),
			adj = c(1, 0), col = cols [iter])
}
cl <- "black"
trace (spc.fit.poly.below, quote ({
					plot (fit.to[,, use.old], col = cl, add = TRUE, lines.args = list (type = "p"), zeroline = NULL);
					lines (fit.to@wavelength, bl, col = cl);
				}), at = 10, print = FALSE)
bl <- spc.fit.poly.below (chondro [1,, 1710 ~ max], poly.order = 1)


###################################################
### chunk number 10: fig4
###################################################
trace (spc.fit.poly.below, quote ({
					plot (fit.to[,, use.old], col = cl, add = TRUE, lines.args = list (pch = 20, type = "p"), zeroline = NULL);
					lines (fit.to@wavelength, bl, col = cl);
					lines (fit.to@wavelength, bl + noise, col = cl, lty = 2)
				}), at = 10, print = FALSE)
cols <- as (HSV(seq (240, 0, length.out = 6), 1, 1), "RGB")
cols@coords [,2] <- cols@coords[,2] / 2
cols <- hex (cols)
bl <- chondro [1] + 15
plot (chondro [1])
for (iter in seq_along (cols)){
	npts <- sum (chondro [[1]] < bl [[]] + noise)
	cl <- cols [iter]
	text (600, 1000 - 50 * iter, paste ("Iter. ", iter, ": ", npts, " support pts.", sep = ""),
			adj = c(0, 0), col = cols [iter])
	bl <- spc.fit.poly.below (chondro [1], poly.order = 1, npts.min = npts - 1, noise = noise)
}
plot (chondro [1], add = TRUE)


###################################################
### chunk number 11: fig5
###################################################
trace (spc.fit.poly.below, quote ({
					plot (fit.to[,, use.old], col = cl, add = TRUE, lines.args = list (pch = 20, type = "p"));
					lines (fit.to@wavelength, bl, col = cl);
					lines (fit.to@wavelength, bl + noise, col = cl, lty = 2)
				}), at = 10, print = FALSE)
cols <- as (HSV(seq (240, 0, length.out = 6), 1, 1), "RGB")
cols@coords [,2] <- cols@coords[,2] / 2
cols <- hex (cols)
bl <- chondro [1] + 15
plot (chondro [1], plot.args = list (ylim = range (chondro [1,, c(600 ~ 650, 1730 ~ 1800)])))
for (iter in seq_along (cols)){
	npts <- sum (chondro [[1]] < bl [[]] + noise)
	cl <- cols [iter]
	cat ("Iteration", iter, ":", npts, "supporting points\n")
	bl <- spc.fit.poly.below (chondro [1], poly.order = 1, npts.min = npts - 1, noise = noise)
}
plot (chondro [1], add = TRUE)
untrace (spc.fit.poly.below)


###################################################
### chunk number 12: cleanup
###################################################
rm (list = ls () ) 



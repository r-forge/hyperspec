###################################################
### chunk number 1: startup
###################################################
#setwd ("~/Uni/workspace/hyperspec.rforge/Vignettes/chondro")
options(SweaveHooks=list(fig=function() par(mar = c (4.1, 4.1, .6, .6))))
options ("width" = 100)
library (hyperSpec)


###################################################
### chunk number 2: import
###################################################
chondro <- scan.txt.Renishaw ("chondro.txt", data = "xyspc")


###################################################
### chunk number 3: emptyfile
###################################################
if (nrow(chondro) == 0)
   rm (chondro) 


###################################################
### chunk number 4: import2
###################################################
chondro


###################################################
### chunk number 5: fig-rawspc
###################################################
plot (chondro, "spcprctl5")


###################################################
### chunk number 6: fig-rawmap
###################################################
print (plotmap (chondro, na.rm = TRUE))


###################################################
### chunk number 7: interp
###################################################
chondro <- spc.loess (chondro, seq (602, 1800, 4))
chondro


###################################################
### chunk number 8: bl
###################################################
baselines <- spc.fit.poly.below (chondro)
chondro <- chondro - baselines


###################################################
### chunk number 9: norm
###################################################
chondro <- sweep (chondro, 1, apply (chondro, 1, mean), "/")
plot (chondro, "spcprctl5")


###################################################
### chunk number 10: perc
###################################################
chondro <- sweep (chondro, 2, apply (chondro, 2, quantile, 0.05), "-")
plot (chondro, "spcprctl5")


###################################################
### chunk number 11: pca
###################################################
pca <- prcomp (~ spc, data = chondro$., center = TRUE)
scores <- decomposition (chondro, pca$x, label.wavelength = "PC", label.spc = "score / a.u.")
loadings <- decomposition (chondro, t(pca$rotation), scores = FALSE, label.spc = "loading I / a.u.")


###################################################
### chunk number 12: pca-pairs eval=FALSE
###################################################
## pairs (scores [[,,1:20]], pch = 19, cex = 0.5)


###################################################
### chunk number 13: pca-identify eval=FALSE
###################################################
## out <- map.identify (scores [,,5])
## out <- c (out, map.identify (scores [,,6]))
## out <- c (out, map.identify (scores [,,7]))


###################################################
### chunk number 14: pca-out
###################################################
out <- c(105, 140, 216, 289, 75, 69)


###################################################
### chunk number 15: pca-cols
###################################################
out
outcols <- c ("red", "blue", "#800080", "orange", "magenta", "brown")

cols <- rep ("black", nrow(chondro))
cols [out] <- outcols


###################################################
### chunk number 16: pca-outspc
###################################################
plot(chondro[1], plot.args = list (ylim = c (1, length (out) + .7)), lines.args = list(  type = "n"))
for (i in seq (along = out)){
   plot(chondro, "spcprctl5", yoffset = i, add = TRUE, col = "gray")
   plot (chondro [out[i]], yoffset = i, col = outcols[i] , add = TRUE, lines.args = list (lwd = 2))
   text (600, i + .33, out [i])  }


###################################################
### chunk number 17: pca-pairs2
###################################################
pairs (scores [[,,1:7]], pch = 19, cex = 1, col = cols)


###################################################
### chunk number 18: outdel
###################################################
chondro <- chondro [- out]


###################################################
### chunk number 19: hca
###################################################
dist <- dist (chondro [[]])
dendrogram <- hclust (dist, method = "ward")


###################################################
### chunk number 20: denddummy eval=FALSE
###################################################
## plot (dendrogram)


###################################################
### chunk number 21: clustmap
###################################################
clusters <- cutree (dendrogram, k = 3)
print (plotmap (chondro, z = as.factor (clusters)))


###################################################
### chunk number 22: dend
###################################################
plot (dendrogram, labels = FALSE, hang = 0)
col.clust <- matlab.palette(3)
points (seq_along (dendrogram$order), rep (-3, length (dendrogram$order)),
        col = col.clust [clusters [dendrogram$order]], pch = "|")


###################################################
### chunk number 23: clustmeans
###################################################
cluster.means <- aggregate (chondro, clusters, mean_pm_sd)
plot(cluster.means, yoffset = rep ((1:3), each = 3), col = rep (matlab.palette (3), each = 3))


###################################################
### chunk number 24: DNA
###################################################
print (plotmap (chondro[, , c( 728 - 1i ~  728 + 1i,
                               782 - 1i ~  782 + 1i,
                              1098 - 1i ~ 1098 + 1i,
                              1240 - 1i ~ 1240 + 1i,
                              1482 - 1i ~ 1482 + 1i,
                              1577 - 1i ~ 1577 + 1i)]))


###################################################
### chunk number 25: cleanup
###################################################
rm (list = ls () ) 



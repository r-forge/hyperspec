###################################################
### chunk number 1: startup
###################################################
options(SweaveHooks=list(fig=function() par(mar = c (4.1, 4.1, 1, .6))))
options ("width" = 100)
library (hyperSpec)

# redefine lattice functions so that the result is printed without external print command
setMethod ("plot",
           signature (x = "hyperSpec", y = "character"),
           function (x, y, ...){
             tmp <- hyperSpec:::.plot (x, y, ...)
             if (is (tmp, "trellis"))
               print (tmp)
             invisible (tmp)
           })


plotmap <- function (...) print (hyperSpec:::plotmap (...))

setMethod ("levelplot", signature (x = "hyperSpec", data = "missing"),
   function (x, data, ...) {
	   l <- hyperSpec:::.levelplot (x = formula (spc ~ x * y), data = x, ...)
		print (l)
	}
)

setMethod ("levelplot", signature (x = "formula", data = "hyperSpec"), 
   function (x, data, ...) print (hyperSpec:::.levelplot (x, data, ...))
)

plotc <- function (...){
   call <- match.call () 
   call [[1]] <- hyperSpec:::plotc 
   print (eval (call))
}

plotvoronoi <- function (...) print (hyperSpec:::plotvoronoi (...))

# set standardized color palettes 
seq.palette <- colorRampPalette (c ("white", "gold", "dark green"), space = "Lab")

seq.palette   <- colorRampPalette (brewer.pal (9, "Greens"), space = "Lab")

seqsq.palette <- function (n) rgb (colorRamp (brewer.pal (9, "Greens"), space = "Lab") 
                                   (seq (1/3, 1, length.out = n)^2), maxColorValue = 255)

YG.palette <- function (n) rgb (colorRamp (brewer.pal (9, "Greens"), space = "Lab") 
                                (seq (1/3, 1, length.out = n)^2), maxColorValue = 255)

										  
div.palette <- colorRampPalette (c("#00008B", "#351C96", "#5235A2", "#6A4CAE", "#8164BA", "#967CC5", 
                                   "#AC95D1", "#C1AFDC", "#D5C9E8", "#E0E3E3", "#F8F8B0", "#F7E6C2", 
											  "#EFCFC6", "#E6B7AB", "#DCA091", "#D08977", "#C4725E", "#B75B46",
											  "#A9432F", "#9A2919", "#8B0000"), space = "Lab")

make.bib <- function (..., file = "") {
  pkg <- c (...)

  toBibtex.citation <- function(object, ...)
    {
      z <- paste("@", attr(object, "entry"), "{", attr(object, "key"), ",", sep="")
      
      if("author" %in% names(object)){
        object$author <- toBibtex(object$author)
      }
      
      for(n in names(object))
        z <- c(z, paste("  ", n, " = {", object[[n]], "},", sep=""))
      
      z <- c(z, "}")
      class(z) <- "Bibtex"
      z
    }

  if (length (pkg) == 0) {
    pkg <- loadedNamespaces()
    pkg <- pkg [! pkg %in% c("graphics", "grDevices", "grid", "methods", "stats", "utils")]
  }
  
  for (p in pkg){
    tmp <- citation (p)
    if (is (tmp, "citation")){
      attr (tmp, "key") <- p
      cat ( toBibtex (tmp), file = file, sep = "\n")
    } else if (length (tmp) == 1){
      attr (tmp [[1]], "key") <- p
      cat( toBibtex (tmp [[1]]), file = file, sep = "\n")
    } else{
      for (i in seq_along (tmp)){
        attr (tmp [[i]], "key") <- paste (p, letters [i], sep = ".")
      cat (toBibtex (tmp[[i]]), file = file, sep = "\n")
      } 
    }
  }
}



###################################################
### chunk number 2: mailme
###################################################
cat ("\\newcommand{\\mailme}{\\href{mailto:", packageDescription ("hyperSpec")$Maintainer, "}{\\texttt{", packageDescription ("hyperSpec")$Maintainer,"}}}\n", sep = "")


###################################################
### chunk number 3:  eval=FALSE
###################################################
## .is.hy (object)
## validObject (object)


###################################################
### chunk number 4: 
###################################################
.is.hy <- hyperSpec:::.is.hy


###################################################
### chunk number 5:  eval=FALSE
###################################################
## sweep (flu, 2, mean, `-`)


###################################################
### chunk number 6: 
###################################################
`+` (3, 5)


###################################################
### chunk number 7:  eval=FALSE
###################################################
## wl (flu) <- new.wavelength.values


###################################################
### chunk number 8: init
###################################################
library (hyperSpec)


###################################################
### chunk number 9: print
###################################################
chondro
summary (chondro)


###################################################
### chunk number 10: nwl
###################################################
nrow (chondro)
nwl (chondro)
ncol (chondro)
dim (chondro)


###################################################
### chunk number 11: names
###################################################
colnames (chondro)


###################################################
### chunk number 12: cbind
###################################################
dim (flu)
dim (cbind (flu, flu))
dim (rbind (flu, flu))


###################################################
### chunk number 13: collapse
###################################################
barb <- collapse (barbituates)
wl (barb)
barb <- orderwl (barb)
barb [[1:3, , min ~ min + 10i]]


###################################################
### chunk number 14: selspc
###################################################
plot (flu, col = "gray")
plot (flu [1 : 3], add = TRUE)


###################################################
### chunk number 15: delspc
###################################################
plot (flu, col = "gray")
plot (flu [-3], add = TRUE)


###################################################
### chunk number 16: selspc2
###################################################
plot (flu, col = "gray")
plot (flu [flu$c > 0.2], add = TRUE)


###################################################
### chunk number 17: sample
###################################################
sample (chondro, 3)


###################################################
### chunk number 18: isample
###################################################
isample (chondro, 3)


###################################################
### chunk number 19: seq
###################################################
seq (chondro, length.out = 3, index = TRUE)
seq (chondro, by = 100)


###################################################
### chunk number 20: data
###################################################
colnames (chondro)
chondro [[1 : 3, 1]]
chondro [[1 : 3, -3]]
chondro [[1 : 3, "x"]]
chondro [[1 : 3, c (TRUE, FALSE, FALSE)]]


###################################################
### chunk number 21: data2
###################################################
flu$c


###################################################
### chunk number 22: data3
###################################################
flu$n <- list (1 : 6, label = "sample no.")


###################################################
### chunk number 23: 
###################################################
plot (paracetamol [,, 2800 ~ 3200])


###################################################
### chunk number 24: 
###################################################
plot (paracetamol [,, 2800 : 3200, wl.index = TRUE])


###################################################
### chunk number 25: 
###################################################
plot (paracetamol [,, -(500 : 1000), wl.index = TRUE])


###################################################
### chunk number 26: 
###################################################
plot (paracetamol [,, c (min ~ 1750, 2800 ~ max)])


###################################################
### chunk number 27: wl2ivec
###################################################
wl2i (flu, 405 : 410)


###################################################
### chunk number 28: wl2ivec2
###################################################
wl2i (flu, 405 ~ 410)


###################################################
### chunk number 29: wl2ivec3
###################################################
wl2i (chondro, 1000 : 1010)


###################################################
### chunk number 30: wl2ivec4
###################################################
wl2i (chondro, 1000 ~ 1010)


###################################################
### chunk number 31: wl2i.minmax
###################################################
wl2i (flu, min ~ 410)


###################################################
### chunk number 32: wl2i.im
###################################################
wl2i (flu, 450 - 2i ~ 450 + 2i)
wl2i (flu, max - 2i ~ max)


###################################################
### chunk number 33: wl2i.list
###################################################
wl2i (flu, 450 - 2i ~ 450 + 2i)
wl2i (flu, c (min ~ 406.5, max - 2i ~ max))


###################################################
### chunk number 34: 
###################################################
laser
wavelengths <- wl (laser)
frequencies <- 2.998e8 / wavelengths / 1000
wl (laser) <- frequencies
labels (laser, ".wavelength") <- "f / THz"
laser
rm (laser)


###################################################
### chunk number 35: 
###################################################
wl (laser, "f / THz") <- frequencies


###################################################
### chunk number 36: 
###################################################
wl (laser) <- list (wl = frequencies, label = "f / THz")


###################################################
### chunk number 37: orderwl
###################################################
barb <- collapse (barbituates [1 : 3])
wl (barb)
barb <- orderwl (barb)
wl (barb)


###################################################
### chunk number 38: data2
###################################################
indexmatrix <- matrix (c (1 : 3, 1 : 3), ncol = 2)
indexmatrix
chondro [[indexmatrix, wl.index = TRUE]]
diag (chondro [[1 : 3, , min ~ min + 2i]])


###################################################
### chunk number 39: data2
###################################################
indexmatrix <- matrix (c (1 : 3, 1 : 3), ncol = 2)
indexmatrix
chondro [[indexmatrix, wl.index = TRUE]]
diag (chondro [[1 : 3, , min ~ min + 2i]])


###################################################
### chunk number 40: cut.wl
###################################################
flu [,, min ~ 408.5]
flu [[,, c (min ~ min + 2i, max - 2i ~ max)]]


###################################################
### chunk number 41: fig-loess
###################################################
plot (paracetamol, wl.range = c (300 ~ 1800, 2800 ~ max), xoffset = 850)
p <- spc.loess (paracetamol, c(seq (300, 1800, 2), seq (2850, 3150, 2)))
plot (p, wl.range = c (300 ~ 1800, 2800 ~ max), xoffset = 850, col = "red", add = TRUE)
b <- spc.bin (paracetamol, 4)
plot (b, wl.range = c (300 ~ 1800, 2800 ~ max), xoffset = 850, 
      lines.args = list (pch = 20, cex = .3, type = "p"), col = "blue", add = TRUE)


###################################################
### chunk number 42: fig-loess-kl
###################################################
plot (paracetamol [, , 1600 ~ 1670])
plot (p [, , 1600 ~ 1670], col = "red", add = TRUE)
plot (b [, , 1600 ~ 1670], col = "blue", add = TRUE)


###################################################
### chunk number 43: ofs
###################################################
offsets <- apply (chondro, 1, min)
chondro.offset.corrected <- sweep (chondro, 1, offsets, "-")


###################################################
### chunk number 44: ofs2
###################################################
chondro.offset.corrected <- sweep (chondro, 1, min, "-")


###################################################
### chunk number 45: bl
###################################################
bl <- spc.fit.poly.below (chondro)
chondro <- chondro - bl


###################################################
### chunk number 46: normalize1
###################################################
chondro <- sweep (chondro, 1, mean, "/")


###################################################
### chunk number 47: norm
###################################################
factors <- 1 / apply (chondro, 1, mean)
chondro <- sweep (chondro, 1, factors, "*")


###################################################
### chunk number 48: centre-flu
###################################################
flu.centered <- sweep (flu, 2, mean, "-")
plot (flu.centered)


###################################################
### chunk number 49: perc
###################################################
perc.5th <- apply (chondro, 2, quantile, 0.05)
chondro <- sweep (chondro, 2, perc.5th, "-")
plot (chondro, "spcprctl5")


###################################################
### chunk number 50: scale-sweep
###################################################
scaled.chondro <- sweep (chondro, 2, var, "/")


###################################################
### chunk number 51: scale2
###################################################
scaled.chondro <- chondro
scaled.chondro [[]] <- scale (scaled.chondro [[]])


###################################################
### chunk number 52: msc eval=FALSE
###################################################
## library (pls)
## chondro.msc <- chondro
## chondro.msc [[]] <- msc (chondro [[]])


###################################################
### chunk number 53: label eval=FALSE
###################################################
## labels (absorbance.spectra)$spc <- "A"


###################################################
### chunk number 54: pca
###################################################
pca <- prcomp (~ spc, data = chondro$., center = FALSE)


###################################################
### chunk number 55: decomp
###################################################
scores <- decomposition (chondro, pca$x, label.wavelength = "PC", 
                         label.spc = "score / a.u.")
scores


###################################################
### chunk number 56: loadings
###################################################
loadings <- decomposition (chondro, t(pca$rotation), scores = FALSE, 
                           label.spc = "loading I / a.u.")
loadings


###################################################
### chunk number 57: retain.col
###################################################
loadings <- decomposition (chondro, t(pca$rotation), scores = FALSE, 
                           retain.columns = TRUE, label.spc = "loading I / a.u.")
loadings[1]$..


###################################################
### chunk number 58: retain
###################################################
chondro$measurement <- 1
loadings <- decomposition (chondro, t(pca$rotation), scores = FALSE, 
                           label.spc = "loading I / a.u.")
loadings[1]$..


###################################################
### chunk number 59: pca-load
###################################################
plot (loadings [1:3], stacked = TRUE)


###################################################
### chunk number 60: pca-score
###################################################
plotmap (scores [,,2], col.regions = div.palette (20))


###################################################
### chunk number 61: pca-smooth
###################################################
smoothed <- scores [,, 1:10] %*% loadings [1:10]


###################################################
### chunk number 62: 
###################################################
library (ggplot2)
p <- ggplot (as.long.df (chondro [1]), aes (x = .wavelength, y = spc)) + geom_line ()                           


###################################################
### chunk number 63: 
###################################################
print (p)


###################################################
### chunk number 64: hca
###################################################
dist <- pearson.dist (chondro [[]])
dendrogram <- hclust (dist, method = "ward")


###################################################
### chunk number 65: dend
###################################################
plot (dendrogram)


###################################################
### chunk number 66: dendcut
###################################################
chondro$clusters <- as.factor (cutree (dendrogram, k = 3))


###################################################
### chunk number 67: clustname
###################################################
levels (chondro$clusters) <- c ("matrix", "lacuna", "cell")


###################################################
### chunk number 68: clustmap
###################################################
cluster.cols <- c ("dark blue", "orange", "#C02020")
plotmap (chondro, clusters ~ x * y, col.regions = cluster.cols)


###################################################
### chunk number 69: clustmean
###################################################
means <- aggregate (chondro, by = chondro$clusters, mean_pm_sd)
plot (means, col = cluster.cols, stacked = ".aggregate", fill = ".aggregate")


###################################################
### chunk number 70: split
###################################################
clusters <- split (chondro, chondro$clusters)
clusters


###################################################
### chunk number 71: tab-fn
###################################################
make.fn.table <- function (){
load ("functions.RData")
functions <- subset (functions, !internal)
functions$group <- functions$group[,drop=TRUE]

TeX.escape <- function (x){
#  x <- gsub ("^\\\\([^\\\\])", "\\\\\\\\\\1", x)
#  x <- gsub ("[^\\\\]\\\\$", "\\1\\\\\\\\", x)
  x <- gsub ("([^\\\\]|^)\\$", "\\1\\\\$", x)
  x <- gsub ("([^\\\\]|^)_", "\\1\\\\_", x)
  x <- gsub ("([^\\\\]|^)%", "\\1\\\\%", x)
  x
}

for (g in levels (functions$group)){
  cat ("\\multicolumn{2}{l}{\\emph{",g, "}}\\\\\n", sep = "")
  df <- t (functions [functions$group == g, c ("name", "description")])
  cat (paste (paste ("\\verb+", df[1,], "+", sep = ""), df[2,], sep = " & ", collapse ="\\\\\n"),"\\\\\n")
}
}
make.fn.table()


###################################################
### chunk number 72: cleanup
###################################################
rm (list = ls () )



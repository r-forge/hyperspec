###################################################
### chunk number 1: startup
###################################################
options(SweaveHooks=list(fig=function() par(mar = c (4.1, 4.1, 1, .6))))
options ("width" = 100)
library (hyperSpec)

# redefine lattice functions so that the result is printed without external print command
setMethod ("plot",
           signature (x = "hyperSpec", y = "character"),
           function (x, y, ...){
             tmp <- hyperSpec:::.plot (x, y, ...)
             if (is (tmp, "trellis"))
               print (tmp)
             invisible (tmp)
           })


plotmap <- function (...) print (hyperSpec:::plotmap (...))

setMethod ("levelplot", signature (x = "hyperSpec", data = "missing"),
   function (x, data, ...) {
	   l <- hyperSpec:::.levelplot (x = formula (spc ~ x * y), data = x, ...)
		print (l)
	}
)

setMethod ("levelplot", signature (x = "formula", data = "hyperSpec"), 
   function (x, data, ...) print (hyperSpec:::.levelplot (x, data, ...))
)

plotc <- function (...){
   call <- match.call () 
   call [[1]] <- hyperSpec:::plotc 
   print (eval (call))
}

plotvoronoi <- function (...) print (hyperSpec:::plotvoronoi (...))

# set standardized color palettes 
seq.palette <- colorRampPalette (c ("white", "gold", "dark green"), space = "Lab")

seq.palette   <- colorRampPalette (brewer.pal (9, "Greens"), space = "Lab")

seqsq.palette <- function (n) rgb (colorRamp (brewer.pal (9, "Greens"), space = "Lab") 
                                   (seq (1/3, 1, length.out = n)^2), maxColorValue = 255)

YG.palette <- function (n) rgb (colorRamp (brewer.pal (9, "Greens"), space = "Lab") 
                                (seq (1/3, 1, length.out = n)^2), maxColorValue = 255)

										  
div.palette <- colorRampPalette (c("#00008B", "#351C96", "#5235A2", "#6A4CAE", "#8164BA", "#967CC5", 
                                   "#AC95D1", "#C1AFDC", "#D5C9E8", "#E0E3E3", "#F8F8B0", "#F7E6C2", 
											  "#EFCFC6", "#E6B7AB", "#DCA091", "#D08977", "#C4725E", "#B75B46",
											  "#A9432F", "#9A2919", "#8B0000"), space = "Lab")

make.bib <- function (..., file = "") {
  pkg <- c (...)

  toBibtex.citation <- function(object, ...)
    {
      z <- paste("@", attr(object, "entry"), "{", attr(object, "key"), ",", sep="")
      
      if("author" %in% names(object)){
        object$author <- toBibtex(object$author)
      }
      
      for(n in names(object))
        z <- c(z, paste("  ", n, " = {", object[[n]], "},", sep=""))
      
      z <- c(z, "}")
      class(z) <- "Bibtex"
      z
    }

  if (length (pkg) == 0) {
    pkg <- loadedNamespaces()
    pkg <- pkg [! pkg %in% c("graphics", "grDevices", "grid", "methods", "stats", "utils")]
  }
  
  for (p in pkg){
    tmp <- citation (p)
    if (is (tmp, "citation")){
      attr (tmp, "key") <- p
      cat ( toBibtex (tmp), file = file, sep = "\n")
    } else if (length (tmp) == 1){
      attr (tmp [[1]], "key") <- p
      cat( toBibtex (tmp [[1]]), file = file, sep = "\n")
    } else{
      for (i in seq_along (tmp)){
        attr (tmp [[i]], "key") <- paste (p, letters [i], sep = ".")
      cat (toBibtex (tmp[[i]]), file = file, sep = "\n")
      } 
    }
  }
}



###################################################
### chunk number 2: mailme
###################################################
cat ("\\newcommand{\\mailme}{\\href{mailto:", packageDescription ("hyperSpec")$Maintainer, "}{\\texttt{", packageDescription ("hyperSpec")$Maintainer,"}}}\n", sep = "")


###################################################
### chunk number 3: rawspc
###################################################
laser <- scan.txt.Renishaw ("rawdata/laser.txt", data = "ts")
plot (laser, "spcprctl5") 


###################################################
### chunk number 4: cut
###################################################
laser <- laser [,,-75~0]
plot (laser, "spcprctl5") 


###################################################
### chunk number 5: wlspc1
###################################################
wl (laser) <- wl (laser) + 50


###################################################
### chunk number 6: wlcalc
###################################################
wl (laser) <- list (
   wl = 1e7 / (1/405e-7 - wl (laser)),
   label = expression (lambda / nm)
   )


###################################################
### chunk number 7: wlspc
###################################################
plot (laser, "spcprctl5") 


###################################################
### chunk number 8: save
###################################################
save (laser, file = "laser.rda") 
laser


###################################################
### chunk number 9: locator eval=FALSE
###################################################
## wls <- locator()$x


###################################################
### chunk number 10: 
###################################################
wls <-  wl (laser)[c (13, 17, 21, 23)]


###################################################
### chunk number 11: markspc
###################################################
plot (laser, "spcmeansd")
cols <- c("black", "blue", "red", "darkgreen")
abline (v = wls, col = cols )  


###################################################
### chunk number 12: ts
###################################################
plotc (laser [,, wls], spc ~ t, groups = .wavelength, type = "b",  cex = 0.3, col = cols)


###################################################
### chunk number 13: tsextra
###################################################
plotc (laser [,, wls], spc ~ t | .wavelength, type = "b", cex = 0.3, col = "black")


###################################################
### chunk number 14: plotmatr
###################################################
plot (laser, "mat", contour = TRUE, col = "#00000060")


###################################################
### chunk number 15: plotmatt
###################################################
levelplot (spc ~ .wavelength * t, laser, contour = TRUE, col ="#00000080")


###################################################
### chunk number 16: libraryrgl
###################################################
library (rgl)


###################################################
### chunk number 17: 
###################################################
open3d (windowRect=c(0,0,1200, 750))    # this is needed only for automatically 
                                        # producing the snapshot


###################################################
### chunk number 18: 
###################################################
laser <- laser [,,404.8 ~ 405.6]
cols <- rep (matlab.palette (nrow (laser)), nwl (laser))

surface3d(y = wl(laser), x = laser$t, z = laser$spc, col =  cols)
surface3d(y = wl(laser), x = laser$t, z = laser$spc + .1 * min (laser), 
          col =  "black", alpha = .2,front = "lines", line_antialias = TRUE)

aspect3d (c(1, 1, 0.25))

axes3d(c('x+-', 'y--', 'z--'))
axes3d ('y--', nticks = 25, labels= FALSE)
mtext3d("t / s", 'x+-', line = 2)
mtext3d("lambda / nm", 'y--', line = 2)
mtext3d("I / a.u.", edge = 'z--', line = 2.5)


###################################################
### chunk number 19:  eval=FALSE
###################################################
## pars <- par3d (no.readonly=TRUE)
## save (pars, file = "par3d.Rdata")


###################################################
### chunk number 20: 
###################################################
load ("par3d.Rdata")                    
par3d(pars)


###################################################
### chunk number 21: 
###################################################
rgl.snapshot("fig/laser3d.png", fmt="png", top=TRUE )


###################################################
### chunk number 22: cleanup
###################################################
rm (list = ls ())



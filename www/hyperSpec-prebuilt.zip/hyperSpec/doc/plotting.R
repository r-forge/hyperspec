###################################################
### chunk number 1: startup
###################################################
options(SweaveHooks=list(fig=function() par(mar = c (4.1, 4.1, 1, .6))))
options ("width" = 100)
library (hyperSpec)

# redefine lattice functions so that the result is printed without external print command
setMethod ("plot",
           signature (x = "hyperSpec", y = "character"),
           function (x, y, ...){
             tmp <- hyperSpec:::.plot (x, y, ...)
             if (is (tmp, "trellis"))
               print (tmp)
             invisible (tmp)
           })


plotmap <- function (...) print (hyperSpec:::plotmap (...))

setMethod ("levelplot", signature (x = "hyperSpec", data = "missing"),
   function (x, data, ...) {
	   l <- hyperSpec:::.levelplot (x = formula (spc ~ x * y), data = x, ...)
		print (l)
	}
)

setMethod ("levelplot", signature (x = "formula", data = "hyperSpec"), 
   function (x, data, ...) print (hyperSpec:::.levelplot (x, data, ...))
)

plotc <- function (...){
   call <- match.call () 
   call [[1]] <- hyperSpec:::plotc 
   print (eval (call))
}

plotvoronoi <- function (...) print (hyperSpec:::plotvoronoi (...))

# set standardized color palettes 
seq.palette <- colorRampPalette (c ("white", "gold", "dark green"), space = "Lab")

seq.palette   <- colorRampPalette (brewer.pal (9, "Greens"), space = "Lab")

seqsq.palette <- function (n) rgb (colorRamp (brewer.pal (9, "Greens"), space = "Lab") 
                                   (seq (1/3, 1, length.out = n)^2), maxColorValue = 255)

YG.palette <- function (n) rgb (colorRamp (brewer.pal (9, "Greens"), space = "Lab") 
                                (seq (1/3, 1, length.out = n)^2), maxColorValue = 255)

										  
div.palette <- colorRampPalette (c("#00008B", "#351C96", "#5235A2", "#6A4CAE", "#8164BA", "#967CC5", 
                                   "#AC95D1", "#C1AFDC", "#D5C9E8", "#E0E3E3", "#F8F8B0", "#F7E6C2", 
											  "#EFCFC6", "#E6B7AB", "#DCA091", "#D08977", "#C4725E", "#B75B46",
											  "#A9432F", "#9A2919", "#8B0000"), space = "Lab")

make.bib <- function (..., file = "") {
  pkg <- c (...)

  toBibtex.citation <- function(object, ...)
    {
      z <- paste("@", attr(object, "entry"), "{", attr(object, "key"), ",", sep="")
      
      if("author" %in% names(object)){
        object$author <- toBibtex(object$author)
      }
      
      for(n in names(object))
        z <- c(z, paste("  ", n, " = {", object[[n]], "},", sep=""))
      
      z <- c(z, "}")
      class(z) <- "Bibtex"
      z
    }

  if (length (pkg) == 0) {
    pkg <- loadedNamespaces()
    pkg <- pkg [! pkg %in% c("graphics", "grDevices", "grid", "methods", "stats", "utils")]
  }
  
  for (p in pkg){
    tmp <- citation (p)
    if (is (tmp, "citation")){
      attr (tmp, "key") <- p
      cat ( toBibtex (tmp), file = file, sep = "\n")
    } else if (length (tmp) == 1){
      attr (tmp [[1]], "key") <- p
      cat( toBibtex (tmp [[1]]), file = file, sep = "\n")
    } else{
      for (i in seq_along (tmp)){
        attr (tmp [[i]], "key") <- paste (p, letters [i], sep = ".")
      cat (toBibtex (tmp[[i]]), file = file, sep = "\n")
      } 
    }
  }
}



###################################################
### chunk number 2: mailme
###################################################
cat ("\\newcommand{\\mailme}{\\href{mailto:", packageDescription ("hyperSpec")$Maintainer, "}{\\texttt{", packageDescription ("hyperSpec")$Maintainer,"}}}\n", sep = "")


###################################################
### chunk number 3: plotspc
###################################################
plotspc (paracetamol)


###################################################
### chunk number 4: plotflu
###################################################
plotc (flu)


###################################################
### chunk number 5: levelplot
###################################################
levelplot ( spc ~ x * y, chondro, aspect = "iso")


###################################################
### chunk number 6: plotmap
###################################################
plotmap (chondro)


###################################################
### chunk number 7: plotspcflu
###################################################
plot (flu, "spc")


###################################################
### chunk number 8: plotchomean
###################################################
plot (chondro, "spcmeansd")


###################################################
### chunk number 9: plotchoprctl
###################################################
plot (chondro, "spcprctile")


###################################################
### chunk number 10: plotchoprctl5
###################################################
plot (chondro, "spcprctl5")


###################################################
### chunk number 11: plotmapcho2
###################################################
plot (chondro, "map")


###################################################
### chunk number 12: plotflu2
###################################################
plot (flu, "c")


###################################################
### chunk number 13: plotts
###################################################
plot (laser, "ts")


###################################################
### chunk number 14: 
###################################################
depth.profile <- new ("hyperSpec",
    spc = as.matrix (rnorm (20) + 1:20),
    data = data.frame (z = 1 : 20),
    label = list (spc = "I / a.u.", 
       z = expression (`/` (z, mu*m)),
       .wavelength = expression (lambda)))


###################################################
### chunk number 15: plotdepth
###################################################
plot (depth.profile, "depth")


###################################################
### chunk number 16: plotmat
###################################################
plot (laser, "mat")


###################################################
### chunk number 17: 
###################################################
levelplot (spc ~ .wavelength * .row, laser)


###################################################
### chunk number 18: wavelength
###################################################
plotspc (paracetamol, 
         wl.range = c (300 ~ 1800, 2800 ~ max), 
         xoffset = 750)


###################################################
### chunk number 19: wavelength-2
###################################################
plotspc (paracetamol[,, 700 ~ 1200])


###################################################
### chunk number 20: abscissa
###################################################
plotspc (paracetamol, wl.reverse = TRUE )


###################################################
### chunk number 21: colours
###################################################
plotspc (flu, col = matlab.dark.palette(6) )


###################################################
### chunk number 22: dots
###################################################
plotspc (paracetamol [,, 2800 ~ 3200], 
         lines.args = list (pch = 20, type = "p"))


###################################################
### chunk number 23: mass
###################################################
plot (barbituates [[1]], lines.args = list (type = "h"))


###################################################
### chunk number 24: add
###################################################
plotspc (chondro[30,,])
plotspc (chondro[300,,], add = TRUE, col = "blue")


###################################################
### chunk number 25: diffline
###################################################
plotspc (paracetamol, 
         zeroline = list (col = "red"))


###################################################
### chunk number 26: 
###################################################
rm (laser)


###################################################
### chunk number 27: add-line
###################################################
plot (laser, "spcmeansd")
abline (v = wl (laser)[c (13, 17, 21, 23)], 
        col = c("black", "blue", "red", "darkgreen") )


###################################################
### chunk number 28: stacked1
###################################################
plotspc (chondro[1:3,,], 
         col = matlab.dark.palette (3),
         stacked = TRUE)


###################################################
### chunk number 29: stacked2
###################################################
cols <- c ("dark blue", "orange", "#C02020")
cluster.means <- aggregate (chondro, 
                            chondro$clusters, 
                            mean_pm_sd)
plot (cluster.means, 
      stacked = ".aggregate",
      fill = ".aggregate",
      col = cols)


###################################################
### chunk number 30: stacked3
###################################################
cluster.means <- aggregate (chondro, 
                            chondro$clusters, 
                            mean_pm_sd)
plotspc (cluster.means, 
         yoffset = rep (c (0,1500,3000), each = 3), 
         col = rep (matlab.dark.palette (3), each = 3))


###################################################
### chunk number 31: 
###################################################
out <- c (25, 376, 559)
outcols <- c ("orange", "magenta", "brown")


###################################################
### chunk number 32: 
###################################################
bl <- spc.fit.poly.below (chondro)
chondro <- chondro - bl
chondro <- sweep (chondro, 1, mean, "/")
chondro <- sweep (chondro, 
                  2, 
                  apply (chondro, 
                         2, 
                         quantile, 
                         0.05),
                  "-")


###################################################
### chunk number 33: stacked4
###################################################
## coordinate system:
plot(chondro[1], 
     plot.args = list (ylim = c (1, length (out) + .7)), 
     lines.args = list( type = "n")
     )
## stacked spectra:
for (i in seq (along = out)){
  plot(chondro, 
       "spcprctl5", 
       yoffset = i,
       col = "gray",
       add = TRUE)
  plot (chondro [out[i]], 
        yoffset = i, 
        col = outcols[i], 
        add = TRUE, 
        lines.args = list (lwd = 2))
  text (650, i + .33, out [i]) }


###################################################
### chunk number 34: 
###################################################
plot (laser, "mat", 
      col.regions = matlab.palette (20) )


###################################################
### chunk number 35: plotmat1
###################################################
levelplot (spc ~ .wavelength * .row, 
           laser,
           col.regions = matlab.palette (20))


###################################################
### chunk number 36: plotmat1a
###################################################
levelplot (spc ~ .wavelength * t, 
           laser)


###################################################
### chunk number 37: plotmat2
###################################################
plot (flu, 
      "mat", 
      contour = TRUE, 
      labels = TRUE, 
      col = "#00000080",
      at = seq (0, 700, by = 50))


###################################################
### chunk number 38: plotmat2a
###################################################
levelplot (spc ~ .wavelength * c,
           flu,
           contour = TRUE,
           labels = TRUE,
           col = "#00000080",
           at = seq (0, 700, by = 50))


###################################################
### chunk number 39: plotc2
###################################################
plotc (laser [,, c (13, 17, 21, 23), 
              wl.index = TRUE], 
       spc ~ t | .wavelength, 
       type = "b", 
       cex = .3)


###################################################
### chunk number 40: plotc3
###################################################
 plotc (laser [,, c (13, 17, 21, 23), 
               wl.index = TRUE], 
        spc ~ t, 
        groups = .wavelength, 
        type = "b", 
        col = c ("black", "blue", "red", "darkgreen"))


###################################################
### chunk number 41: lin-cal-2
###################################################
plotc (flu)


###################################################
### chunk number 42: 
###################################################
flu <- flu[,,450]


###################################################
### chunk number 43: lin-cal-2a
###################################################
plotc (flu, ylab = expression (I ["450 nm"] / a.u.))


###################################################
### chunk number 44: lin-cal-3
###################################################
plotc (flu,
       xlim = range (0, flu$c), 
       ylim = range (0, flu$spc))


###################################################
### chunk number 45: 
###################################################
calibration <- lm (c ~ spc, data = flu$.)


###################################################
### chunk number 46: 
###################################################
I <- c (125, 400)
conc <- predict (calibration,
                 newdata = list (spc = as.matrix (I)),
                 interval = "prediction",
                 level = .99)


###################################################
### chunk number 47: 
###################################################
int <- list (spc = as.matrix (seq (min (flu), 
               max (flu), length.out = 25) ) )
ci <- predict (calibration, 
               newdata = int, 
               interval = "confidence", 
               level = .99)
panel.ci <- function (x, y, ...,
                      intensity, ci.lwr, ci.upr, 
                      ci.col = "#606060") {
  panel.xyplot (x, y, ...)
  panel.lmline (x, y, ...)
  panel.lines (ci.lwr, intensity, col = ci.col)
  panel.lines (ci.upr, intensity, col = ci.col)
}


###################################################
### chunk number 48: lin-cal-4
###################################################
plotc (flu, 
       panel = panel.ci,
       intensity = int$spc,
       ci.lwr = ci [, 2],
       ci.upr = ci [, 3])


###################################################
### chunk number 49: 
###################################################
flu$type <- "data points"


###################################################
### chunk number 50: 
###################################################
tmp <- new ("hyperSpec", 
            spc = as.matrix(seq (min (flu), 
              max(flu), length.out = 25)),
            wavelength = 450)
ci <-  predict (calibration, newdata = tmp$., 
                interval = "confidence", 
                level = 0.99)
tmp <- tmp [rep (seq (tmp, index = TRUE), 3)]
tmp$c <- as.numeric (ci)
tmp$type <- rep (colnames (ci), each = 25)
flu$file <- NULL
flu <- rbind (flu, tmp)


###################################################
### chunk number 51: 
###################################################
panel.predict <- function (x, y, ..., 
                 intensity, ci, pred.col = "red", 
                           pred.pch = 19, 
                           pred.cex = 1) {
   panel.xyplot (x, y, ...)
   mapply (function (i, lwr, upr, ...) {
                 panel.lines (c (lwr, upr), 
                              rep (i, 2), ...)
              }, 
           intensity, ci [, 2], ci [, 3], 
           MoreArgs = list (col = pred.col))
   panel.xyplot (ci [, 1], intensity, 
                 col = pred.col, pch = pred.pch, 
                 cex = pred.cex, type = "p")
}


###################################################
### chunk number 52: lin-cal-5
###################################################
plotc (flu, groups = type, type = c("l", "p"),
       col = c ("black", "black", "#606060", 
         "#606060"), 
       pch = c (19, NA, NA, NA), cex = 0.5, 
       lty = c (0, 1, 1, 1),
       panel = panel.predict,
       intensity = I,
       ci = conc,
       pred.cex = 0.5)


###################################################
### chunk number 53: plotmap-clu
###################################################
plotmap (chondro, clusters ~ x * y)


###################################################
### chunk number 54: plotmap-col
###################################################
cols <- c ("dark blue", "orange", "#C02020") 
print (plotmap (chondro,
                clusters ~ x * y,
                col.regions = cols))


###################################################
### chunk number 55: plotmap-wave
###################################################
plotmap (chondro[, , c( 728, 782, 1098, 1240, 
                       1482, 1577)])


###################################################
### chunk number 56: 
###################################################
library (rgl)


###################################################
### chunk number 57: 
###################################################
open3d (windowRect=c(0,0,1200, 750))    # this is needed only for automatically 
                                        # producing the snapshot


###################################################
### chunk number 58: 
###################################################
laser <- laser [,,404.8 ~ 405.6]
cols <- rep (matlab.palette (nrow (laser)), nwl (laser))
surface3d (y = wl (laser), x = laser$t, 
           z = laser$spc, col =  cols)
aspect3d (c(1, 1, 0.25))
axes3d(c('x+-', 'y--', 'z--'))
axes3d ('y--', nticks = 25, labels= FALSE)
mtext3d("t / s", 'x+-', line = 2)
mtext3d("lambda / nm", 'y--', line = 2)
mtext3d("I / a.u.", edge = 'z--', line = 2.5)


###################################################
### chunk number 59: 
###################################################
load ("par3d.Rdata")                    
par3d(pars)
rgl.snapshot("fig/fig-3D.png", fmt="png", top=TRUE )


###################################################
### chunk number 60: plotmap-print
###################################################
print (plotmap (chondro))


###################################################
### chunk number 61:  eval=FALSE
###################################################
## spc.identify (plotspc (paracetamol, wl.range = c (600 ~ 1800, 2800 ~ 3200), xoffset = 800))


###################################################
### chunk number 62:  eval=FALSE
###################################################
## map.identify (chondro)


###################################################
### chunk number 63:  eval=FALSE
###################################################
## plot (laser, "mat")
## trellis.focus ()
## grid.locator ()


###################################################
### chunk number 64: cleanup
###################################################
rm (list = ls () )



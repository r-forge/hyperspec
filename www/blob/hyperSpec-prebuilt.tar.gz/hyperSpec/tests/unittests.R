library ("hyperSpec")
hy.unittest ()

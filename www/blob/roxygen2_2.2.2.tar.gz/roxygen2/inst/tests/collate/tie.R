#' @include collate/shirt.R
NULL

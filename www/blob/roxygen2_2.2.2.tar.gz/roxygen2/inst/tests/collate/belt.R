#' @include collate/pants.R
#' @include collate/shirt.R
NULL

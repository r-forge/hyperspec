#' @include collate/socks.R
#' @include collate/undershorts.R
#' @include collate/pants.R
NULL

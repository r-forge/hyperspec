#' A.
#'
#' @param x X
a <- function(x) {}


#' B
#'
#' @param y Y
b <- function(y) {}

#' C
#' 
#' @inheritParams a
#' @inheritParams b
c <- function(x, y) {}
###################################################
### chunk number 1: fig-rawspc
###################################################
library (hyperSpec)
laser <- scan.txt.Renishaw ("laser.txt", data = "ts")
plot (laser, "spcprctl5") 


###################################################
### chunk number 2: fig-cut
###################################################
laser <- laser [,,-75~0]
plot (laser, "spcprctl5") 


###################################################
### chunk number 3: wlspc1
###################################################
wl (laser) <- wl (laser) + 50


###################################################
### chunk number 4: wlcalc
###################################################
wl (laser) <- list (
   wl = 1e7 / (1/405e-7 - wl (laser)),
   label = expression (lambda / nm)
   )


###################################################
### chunk number 5: fig-wlspc
###################################################
plot (laser, "spcprctl5") 


###################################################
### chunk number 6: save
###################################################
save (laser, file = "laser.rda") 
laser


###################################################
### chunk number 7: locator eval=FALSE
###################################################
## wl2i (laser, locator()$x)
## 


###################################################
### chunk number 8: fig-markspc
###################################################
plot (laser, "spcmeansd")
abline (v = wl (laser)[c (13, 17, 21, 23)], col = c("black", "blue", "red", "darkgreen") )  


###################################################
### chunk number 9: fig-ts
###################################################
plotc (laser[,,13, wl.index = TRUE], use.c = "t", 
    plot.args = list (type = "b", col = "black", ylim = range (laser), pch = 20)) 
plotc (laser[,,17, wl.index = TRUE], use.c = "t", add = TRUE,
    plot.args = list (type = "b", col = "blue", ylim = range (laser), pch = 20)) 
plotc (laser[,,21, wl.index = TRUE], use.c = "t", add = TRUE,
         plot.args = list (type = "b", col = "red", ylim = range (laser), pch = 20)) 
plotc (laser[,,23, wl.index = TRUE], use.c = "t", add = TRUE,
         plot.args = list (type = "b", col = "darkgreen", ylim = range (laser), pch = 20)) 


###################################################
### chunk number 10: cleanup
###################################################
rm (list = ls ())



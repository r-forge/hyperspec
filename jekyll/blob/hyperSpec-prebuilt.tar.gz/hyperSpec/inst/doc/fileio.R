### R code from vignette source 'fileio.Rnw'


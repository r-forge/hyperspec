### R code from vignette source 'chondro.Rnw'

